const express = require('express');
const router = express.Router();
const db = require('../db'); // Callback-Version der Datenbankverbindung

// GET /cart - Warenkorb abrufen
router.get('/', (req, res) => {
    const userId = req.user && req.user.userId;

    if (!userId) {
        console.error('Fehler: Benutzer-ID fehlt im Request.');
        return res.status(400).json({ error: 'Benutzer-ID fehlt im Request' });
    }

    console.log('Benutzer-ID für Warenkorbabfrage:', userId);

    db.query(
        'SELECT c.product_id, p.title, c.quantity, p.price FROM cart c JOIN product p ON c.product_id = p.product_id WHERE c.user_id = ?',
        [userId],
        (err, results) => {
            if (err) {
                console.error('Fehler beim Abrufen des Warenkorbs:', err);
                return res.status(500).json({ error: 'Fehler beim Abrufen des Warenkorbs' });
            }

            console.log('Warenkorbdaten aus der Datenbank:', results);

            if (results.length === 0) {
                console.log('Warenkorb ist leer.');
                return res.status(200).json([]);
            }

            res.status(200).json(results);
        }
    );
});

module.exports = router;



// POST /cart - Produkt zum Warenkorb hinzufügen
router.post('/', async (req, res) => {
    const { userId, productId, quantity } = req.body;

    if (!userId || !productId || !quantity) {
        return res.status(400).json({ error: 'Ungültige Anfrage' });
    }

    try {
        await db.query(
            'INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + ?',
            [userId, productId, quantity, quantity]
        );
        res.status(201).json({ message: 'Produkt erfolgreich zum Warenkorb hinzugefügt' });
    } catch (error) {
        console.error('Fehler beim Hinzufügen zum Warenkorb:', error);
        res.status(500).json({ error: 'Fehler beim Hinzufügen zum Warenkorb' });
    }
});

module.exports = router;
